//go:binary-only-package

package binarypkg
